make build ;
export CROSS_COMPILE=/toolchain/marvell/bin/aarch64-marvell-linux-gnu-  ;
export ARCH=arm64 ;
KERNELDIR=/home/marvell/linux-4.4.52 ;
